package pl.edu.agh.kis.pz1;

public class InternalServerException extends Exception {
    public InternalServerException(String message) {
        super(message);
    }
}
