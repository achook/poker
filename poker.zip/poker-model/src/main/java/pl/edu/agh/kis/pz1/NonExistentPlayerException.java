package pl.edu.agh.kis.pz1;

public class NonExistentPlayerException extends Exception {
    public NonExistentPlayerException(String message) {
        super(message);
    }
}
