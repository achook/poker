package pl.edu.agh.kis.pz1;

public class ServerLogger extends Log {
    @Override
    protected void logln(String message) {
        // TODO
        super.logln(message);
    }

}
